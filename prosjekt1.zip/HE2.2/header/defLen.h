#include <stdlib.h>
#include <stdio.h>
#include <string.h>                  //-------- Her definerer jeg konstanter som jeg kommer til å bruke i programmet mitt samt en struct
#include <unistd.h>                 //som jeg kommer til å bruke for å splitte melding i mindre deler med en bestemt størrelse for å sende
#include <sys/types.h>             //som pakkeserie til klient --------
#include <sys/dir.h>
#include <sys/stat.h>
#include <signal.h>
#include <ctype.h>
#include <stdint.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#define DIR_LENGTH 256     //directory
#define CMD_LENGTH 32     //kommando
#define FILE_LENGTH 256  //fil
#define PCK_LENGTH 256  //pakke
#define KLIENT_NR 128  //klient nummer


struct msg_del{
	uint32_t antall_Char; //antall tegn
	char msg_Innhold[PCK_LENGTH]; //hva som msg inneholder
};