#include "defLen.h"

//--- Her definerer jeg alle metoder som jeg kommer til å bruke i klient-help
//programmet. Jeg har også inkudert alle nødvendige biblioteker i defLen.h for
//å ikke skrive dem hver gang på nytt. ---

void m_gethost(char hostName[], char ip[]);

void manage_ls(char buf[]);                                 
int manage_nr_for_ls(char buf[]);

void getFilename(char *buf,int nr, char *fileName);
void menu_for_CD();

int hent_filNavnNr_via_nr(int antall, char *buf);
int hent_filNavnNr_for_CAT(int antall, char *buf);

char *receive_Serial_Pack(int sd);