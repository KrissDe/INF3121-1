#include "defLen.h"

//--- Her definerer jeg alle metoder som jeg kommer til å bruke i server-help
//programmet samt en struct klient som blir brukt videre i programmet ---

struct klient{                                                 
	int id;                                               
	char klientDir[DIR_LENGTH];//current directory
	char orig_klientDir[DIR_LENGTH];//original directory
};


void server_start(); 
void server_stop(); 

void addLista(int id);
void deleteLista(int id);
void update_i_Lista(int id, char *new_klientDir);

void utfore_ls(int sd, char *filNavn, unsigned int *filLength);
void utfore_pwd(int sd, char *path_output);
void utfore_cat(int sd, char *filNavn, char *msg);
void utfore_fileInfo(int sd, char *filNavn, char *msg);
void utfore_cd(int sd, char *new_path, char *msg);

void send_Serial_Package(int sd, char *msg, int msgLen,fd_set *hoved );