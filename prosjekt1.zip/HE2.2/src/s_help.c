#include "../header/s_help.h"

struct klient *lista[KLIENT_NR]; //struct for våre file descriptor sets


void server_start(){ //metode for å starte serveren
	int i;
	for(i = 0; i<KLIENT_NR;i++){
		lista[i] = NULL;
	}
}

void server_stop(){ //metode for å avslutte serveren
	int i;
	for(i = 0; i<KLIENT_NR;i++){
		if(lista[i] != NULL){ //hvis denne plassen i arrayen ikke er tom
			close(lista[i]->id);
			free(lista[i]);
		}
	}
}

int check_Id(int id){ //metoden for å sjekke id
	int i;
	for(i=0; i<KLIENT_NR; i++){
		if(lista[i] != NULL){
			if(lista[i]->id == id){ //hvis data i denne plassen i arrayen stemmer med id
				return 1;
			}
		}
	}
	return 0;
}

void addLista(int id){ //metode for å legge til lista
	if(check_Id(id) == 1){
		perror("Id already exists\n");
		return;
	}

	struct klient *new_klient = (struct klient *)malloc(sizeof(struct klient)); //initial directory
	new_klient ->id = id;
	memset(new_klient->klientDir,0,DIR_LENGTH);
	memset(new_klient->orig_klientDir,0,DIR_LENGTH);

	char orig_path[DIR_LENGTH]; //original path
	memset(orig_path,0,DIR_LENGTH);
	strcpy(new_klient->klientDir, getcwd(orig_path, sizeof(orig_path)));
	strcpy(new_klient->orig_klientDir, getcwd(orig_path, sizeof(orig_path)));
      
	int i;
	for(i=0; i<KLIENT_NR; i++){
		if(lista[i] == NULL){ //hvis denne plassen i arrayen er tom
			lista[i] = new_klient; 
			return;
		}
	}
	perror("No space for more data.\n"); //hvis i er større en antall mulige klienter
}

void deleteLista(int id){ //metode for å slette fra lista
	int i;
	for(i=0; i<KLIENT_NR; i++){
		if(lista[i] != NULL){ //hvis denne plassen i arrayen ikke er tom
			if(lista[i]->id == id){ // og er lik oppgitt id
				free(lista[i]);
				lista[i] = NULL;
				return;
			}
		}
	}
	fprintf(stderr, " Id not found\n"); //hvis i er større en antall mulige klienter
}

void update_i_Lista(int id, char *new_klientDir){ //oppdatere lista
	int i;
	for(i=0; i<KLIENT_NR; i++){
		if(lista[i] != NULL){ //hvis denne plassen i arrayen ikke er tom
			if(lista[i]->id == id){ //og er lik oppgitt id
				strcpy(lista[i]->klientDir, new_klientDir);
				return;
			}
		}
	}
	fprintf(stderr, "Id not found\n");
}

void utfore_ls(int sd, char *filNavn, unsigned int *filLength){ //utfører operasjoner knyttet til ls
	char path[DIR_LENGTH]; memset(path,0,DIR_LENGTH);

	int i;
	for(i=0; i<KLIENT_NR; i++){
		if(lista[i] != NULL){//hvis ikke tom
			if(lista[i]->id == sd){//og er lik socket
				strcpy(path, lista[i]->klientDir);
				break;
			}
		}
	}

	DIR *dir;
	struct dirent *d; //struct for directory entries
	dir = opendir(path); //opening directory stream

	if(dir){
		unsigned int index_b = 0;
		while((d = readdir(dir)) != NULL){//frem til slutten av directory entry
			int i = 0;
			if(strcmp(d->d_name, ".") == 0 || strcmp(d->d_name, "..") == 0) continue;

			while(i<strlen(d->d_name)){
				filNavn[index_b++] = d->d_name[i++];//fyller arrayen filNavn med data
			}
			filNavn[index_b++] = '\n';//ny linje
		}
		filNavn[index_b] = '\0';//glemmer ikke 0-byte til slutt
		*filLength = ++index_b;
		closedir(dir);//lukker directory
	}
}

void hent_orig_pwd(int sd, char *path_output){ //henter original path
	int i;
	for(i=0; i<KLIENT_NR; i++){
		if(lista[i] != NULL){//hvis ikke tom
			if(lista[i]->id == sd){//og lik socket
				strcpy(path_output,lista[i]->orig_klientDir);
				return;
			}
		}
	}
}

void utfore_pwd(int sd, char *path_output){//får current directory
	int i;
	for(i=0; i<KLIENT_NR; i++){
		if(lista[i] != NULL){
			if(lista[i]->id == sd){
				strcpy(path_output,lista[i]->klientDir);
				return;
			}
		}
	}
}

void utfore_fileInfo(int sd, char *filNavn, char *msg){ //får filinfo
	char path[DIR_LENGTH]; memset(path,0,DIR_LENGTH);
	utfore_pwd(sd, path);//får current directory først
	strcat(path,"/");
	strcat(path, filNavn);
	struct stat sb;

	if (stat(path, &sb) == -1) {//får filstatus, -1 hvis feil
		strcpy(msg, "File not found");
		return;
	}

	switch (sb.st_mode & S_IFMT) {//check file mode
		case S_IFBLK: snprintf(msg, DIR_LENGTH, "! %s is a block device\n", filNavn);  break;
		case S_IFCHR: snprintf(msg, DIR_LENGTH, "! %s is a character device\n", filNavn);  break;
		case S_IFDIR: snprintf(msg, DIR_LENGTH, "! %s is a directory\n", filNavn); break;
		case S_IFIFO: snprintf(msg, DIR_LENGTH, "! %s is a FIFO/pipe\n", filNavn); break;
		case S_IFLNK: snprintf(msg, DIR_LENGTH, "! %s is a symlink\n", filNavn);   break;
		case S_IFREG: snprintf(msg, DIR_LENGTH, "! %s is a regular file\n", filNavn); break;
		case S_IFSOCK:snprintf(msg, DIR_LENGTH, "! %s is a socket\n", filNavn);   break;
		default: snprintf(msg, DIR_LENGTH, "! %s is a unknown?\n", filNavn);  break;
	}
}

void utfore_cat(int sd, char *filNavn, char *msg){//filinnhold
	FILE *f = NULL;
	f = fopen(filNavn, "rb");//åpner filen
	char reader[1];
	int i = 0;

	while(!feof(f)){ //frem til slutten av fila
		fread(reader,1,1,f);//leser tegn for tegn
		if(isprint(reader[0]) != 0 || reader[0] == '\n' || reader[0] == '\t'){
			msg[i++] = reader[0];
		}else{
			msg[i++] = '.'; //tegn som ikke er printable, settes til punktum-tegn
		}
	}
	fclose(f);//lukker filen
	msg[i-1] = '\0';//glemmer ikke 0-byten til slutt
}

void utfore_cd(int sd, char *new_path, char *msg){
	char path[DIR_LENGTH]; memset(path, 0, DIR_LENGTH);
	char orig_path[DIR_LENGTH]; memset(orig_path, 0, DIR_LENGTH);

	utfore_pwd(sd, path);//får current og original directory
	hent_orig_pwd(sd,orig_path);

	if(chdir(path) == -1){//set current directory to my directory
		strcpy(msg,"Wrong map!");
		return;
	}
	
	if(chdir(new_path) == -1){//utfører kommando
		strcpy(msg, "Map not found.");
		return;
	}
	memset(path, 0, DIR_LENGTH);
	getcwd(path, DIR_LENGTH);//kopierer tilbake

	if(strncmp(orig_path, path, strlen(orig_path)) != 0){//passer på at vi ikke går før original directory
		strcpy(msg,"You can not move before original path!");
		return;
	}

	update_i_Lista(sd, path); //oppdaterer
	strcpy(msg,"Update CD status: OK");
}

void send_Serial_Package(int sd, char *msg, int msgLen,fd_set *hoved ){ //sender pakkeserie til klient
	int SIZE_STRUCT = sizeof(struct msg_del); // størrelse av vår struct som skal splitte data i deler for pakken
	struct msg_del varsel_om_mld_size;
	memset(&varsel_om_mld_size, 0, SIZE_STRUCT);
	varsel_om_mld_size.antall_Char = htonl(msgLen); //konverterer fra host til nett

	int st;
	st = send(sd, (void *)&varsel_om_mld_size, SIZE_STRUCT, 0); //sender til klient

	if(st < 0){
		perror("Error while receiving\n");
		FD_CLR(sd, hoved);//slette
		deleteLista(sd);
		close(sd);
		return;
	}
	int i = 0;
	fprintf(stderr,"Send to %d with total bytes %d .\n", sd, msgLen);

	#ifdef DEBUG 
		fprintf(stderr,"Send to %d.\n", sd);
	#endif 

	while(i < msgLen){
		int j =0;
		struct msg_del delen_av_msg;
		memset(&delen_av_msg, 0, SIZE_STRUCT);

		while(j < PCK_LENGTH){//splitter melding i pakker lik pakkestørrelse
			if(i < msgLen) delen_av_msg.msg_Innhold[j++] = msg[i++];
			else break;
		}
		delen_av_msg.antall_Char = htonl(j);//konverterer til nett
		st = send(sd, (void *)&delen_av_msg, SIZE_STRUCT, 0);//sender til klient

		if(st < 0){
				perror("Error while receiving\n");
				FD_CLR(sd, hoved);
				deleteLista(sd);
				close(sd);
				return;
		}

		fprintf(stderr,"   Har sendt %d bytes. Det er en del av mld med size %d bytes.\n", st, j);//check
		#ifdef DEBUG 
			fprintf(stderr,"    Har sendt %d bytes. Det er en del av mld med size %d bytes.\n", st, j);
		#endif 
	}
}

















