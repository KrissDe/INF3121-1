#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <signal.h>
#include "../header/s_help.h"

fd_set hoved, tmp; //hoved og temporary file descriptor lists for select()
int max_fd; //maks antall file descriptors

void avslutte(){          //metode for å avslutte programmet
	printf("Closing..");
	server_stop();
	exit(0);
}

void exec_command(int sd, char *cmd){ //metode for å håndtere kommando som bruker tastet inn
	if(strcmp(cmd, "ls") == 0){
		printf("Motatt kommando: ls\n"); //check

		char filMengde[DIR_LENGTH]; memset(filMengde,0,DIR_LENGTH);
		unsigned int len;

		utfore_ls(sd, filMengde, &len); //metoden som utfører operasjoner knyttet til kommandoen
		send_Serial_Package(sd, filMengde, len, &hoved); //metode som sender pakkeserie til klienten

	}else if(strcmp(cmd, "pwd") == 0){
		printf("Motatt kommando: pwd\n");  //check

		char path_output[DIR_LENGTH]; memset(path_output,0,DIR_LENGTH);

		utfore_pwd(sd,path_output);  //samme prinsippet som over
		send_Serial_Package(sd, path_output, strlen(path_output)+1, &hoved);

	}else if(strcmp(cmd, "cd") == 0){
		 printf("Motatt kommando: cd\n"); //check

		 char newPath[DIR_LENGTH]; memset(newPath,0,DIR_LENGTH);
		 int nbytes; 
		 nbytes = recv(sd, newPath, DIR_LENGTH, 0); //mottar path-navn fra klienten

		 if(nbytes == 0){
			printf("%d closed connection\n", sd);
			FD_CLR(sd, &hoved);
			deleteLista(sd);
			close(sd);
			return;
		}else if(nbytes < 0){
			perror("Error while receiving\n");
			FD_CLR(sd, &hoved);
			deleteLista(sd);
			close(sd);
			return;
		}
		 
		  char path_output[DIR_LENGTH]; memset(path_output, 0, DIR_LENGTH);

		  utfore_cd(sd, newPath, path_output); //utfører operasjoner
		  send_Serial_Package(sd, path_output, strlen(path_output)+1, &hoved); //sender pakkeserie

	}else if(strcmp(cmd, "getFileInfo") == 0){
		 printf("Motatt getFileInfo\n");
		 
		 char filNavn[FILE_LENGTH];
		 memset(filNavn,0,FILE_LENGTH);
		 int nbytes = recv(sd, filNavn, FILE_LENGTH, 0);
		 if(nbytes == 0){
			printf("%d closed connection\n", sd);
			FD_CLR(sd, &hoved);
			deleteLista(sd);
			close(sd);
			return;
		}else if(nbytes < 0){
			perror("Receive\n");
			FD_CLR(sd, &hoved);
			deleteLista(sd);
			close(sd);
			return;
		}
		 
		char msg[DIR_LENGTH];
		memset(msg,0,DIR_LENGTH);
		
		 utfore_fileInfo(sd, filNavn, msg);
		 send_Serial_Package(sd, msg, strlen(msg)+1, &hoved);

	}else if(strcmp(cmd, "cat") == 0){
		 printf("Motatt kommando: cat\n"); //check

		 char filNavn[FILE_LENGTH]; memset(filNavn,0,FILE_LENGTH);
		 int nbytes = recv(sd, filNavn, FILE_LENGTH, 0); //mottar filnavn fra klienten

		 if(nbytes == 0){
			printf("%d closed connection\n", sd);
			FD_CLR(sd, &hoved);
			deleteLista(sd);
			close(sd);
			return;
		}else if(nbytes < 0){
			perror("Error while receiving\n");
			FD_CLR(sd, &hoved);
			deleteLista(sd);
			close(sd);
			return;
		}

		char path[DIR_LENGTH]; memset(path,0,DIR_LENGTH);
		utfore_pwd(sd, path); //henter current directory først
		strcat(path,"/");
		strcat(path, filNavn);
		struct stat sb;

		if (stat(path, &sb) == -1) { //får filstatus, -1 hvis feil
		  return;
		}

		if((sb.st_mode & S_IFMT) == S_IFREG){ //if file is regular 
			char msg[sb.st_size]; memset(msg,0,sb.st_size);
			utfore_cat(sd, path,msg);
			send_Serial_Package(sd, msg, strlen(msg)+1, &hoved); //sender seriepakke
		}else{
			char msg[DIR_LENGTH]; memset(msg,0,DIR_LENGTH);
			strcpy(msg,"ONLY REGULAR FILE CAN USE cat !!!"); //error hvis en valgt fil ikke er ordinær (mappe o.l.)
			send_Serial_Package(sd, msg, strlen(msg)+1, &hoved);//sender pakkeserie med beskjed til klienten
		} 
	}else{
		printf("Generell feil! \n");
	}
}

void utfore_new_connection(int sd){ //hvis vi fikk ny tilkobling
	struct sockaddr_in clientaddr;
	memset(&clientaddr, 0, sizeof(struct sockaddr_in));
	int client_sd;
	socklen_t addrlen = sizeof(clientaddr);
	client_sd = accept(sd, (struct sockaddr *)&clientaddr, &addrlen); //akseptere tilkobling fra klienten

	if(client_sd == -1){
		perror("Can not accept connection!");
		return;
	}

	char client_ip[INET_ADDRSTRLEN]; memset(client_ip, 0, INET_ADDRSTRLEN);
	inet_ntop(clientaddr.sin_family, &clientaddr.sin_addr.s_addr, client_ip, INET_ADDRSTRLEN); //konvertere ip til lesebar tilstand
	printf("Connection from %s with port %d with socket descriptor %d\n", client_ip, ntohs(clientaddr.sin_port), client_sd);

	if(client_sd > max_fd){ //hvis klient socket er større enn maks antall file descriptors
		max_fd = client_sd;
	}

	FD_SET(client_sd, &hoved); 
	addLista(client_sd); //legge til lista
}

void utfore_old_connection(int sd){ //hvis det er tilkobling fra før
	int nbytes;
	char buf[CMD_LENGTH]; memset(buf, 0, CMD_LENGTH);
	nbytes = recv(sd, buf, CMD_LENGTH, 0); //mottar kommando fra klienten
	printf("Main received %s -- %d bytes \n", buf, nbytes); //check

	if(nbytes == 0){
		printf("%d closed connection\n", sd);
		FD_CLR(sd, &hoved);
		deleteLista(sd);
		close(sd);
		return;
	}else if(nbytes < 0){
		perror("Error while receiving\n");
		FD_CLR(sd, &hoved);
		deleteLista(sd);
		close(sd);
		return;
	}

	//---- nå har vi samlet data -----
	exec_command(sd, buf); //og kan eksekvere kommando
}

int main(int argc, char *argv[]){
	signal(SIGINT, avslutte); //håndterer signaler(Ctrl-C, Ctrl-Z) og sender dataelementen til metoden som skal avslutte programmet 
	signal(SIGTSTP, avslutte);
	signal(SIGQUIT, avslutte);

	if(argc != 2){ //hvis bruker taster inn feil antall kommandolinjeargumenter
		printf("Usage: %s port\n", argv[0]);
		avslutte();
	}

	int port = atoi(argv[1]);
	int sd;

	if(port < 1024 || port > 65536){ //portnummer bør være i disse grensene 
		printf("Check port nr., it's over boundaries allowed");
		avslutte();
	}

	struct sockaddr_in serveraddr;
	memset(&serveraddr, 0, sizeof(struct sockaddr_in));

	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(port);
	serveraddr.sin_addr.s_addr = INADDR_ANY;

	if((sd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0){ //lager socket
		fprintf(stderr, "Error while connecting to socket\n");
		exit(1);
	}

	int activate =1;
	setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, &activate, sizeof(int)); //extra options for socket

	if(bind(sd, (struct sockaddr *)&serveraddr, sizeof(serveraddr)) < 0){ //binding
		fprintf(stderr, "Error while binding \n");
		close(sd);
		exit(1);
	}

	if((listen(sd, SOMAXCONN)) < 0){ //listening
		fprintf(stderr, "Error while listening \n");
		close(sd);
		exit(1);
	}

	FD_ZERO(&hoved);       //slette alt fra sets
	FD_ZERO(&tmp);
	FD_SET(sd, &hoved);
	max_fd = sd;

	server_start(); //starter serveren
	printf("Server starts at port %d\n", port);

	while(1){
		tmp = hoved;

		if(select(max_fd+1, &tmp, NULL, NULL, NULL) == -1){ //selecting
			perror("Error while select()ing ");
			avslutte();
		}

		int i = 0;
		for(; i<=max_fd; i++){
			if(FD_ISSET(i, &tmp)){ //vi fikk tilkobling
				if(i == sd){//hvis det er ny tilkobling
					utfore_new_connection(i);
				}else{//hvis det er tilkobling fra før
					utfore_old_connection(i);
				}
			}
		}
	}
	return 0;
}