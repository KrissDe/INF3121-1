#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <signal.h>
#include "../header/k_help.h"

int sd; //socket descriptor
void display_menu();
void inputAction(char a, int sd); //behandler kommando

void avslutte(){                  //metode for å avslutte programmet
	printf("Closing..");
	close(sd);
	exit(0);
}
  

int main(int argc, char *argv[]){//./client localhost 7000

//signal() funsksjon  som lytter på signal(Ctrl-C, Ctrl-Z), og sender den dataelementen til funksjonen som avslutter programmet
	signal(SIGINT, avslutte);
	signal(SIGTSTP, avslutte);
	signal(SIGQUIT, avslutte);

	char ip[50];
	memset(ip,0,50);

	if(argc != 3){                  //hvis bruker taster inn feil 
		perror("Like this: ./client localhost 7000\n");
		exit(-1);
	}

	m_gethost(argv[1], ip); //funsksjonen for å få host address(legge inn i 'ip') hvis bruker taster inn host navn

	int port = atoi(argv[2]);
	printf("Connection OK to the hostname %s and port %d with IP %s\n", argv[1], port, ip); //bekreftelse på at tilkobling vellykket

	struct sockaddr_in serveraddr; 
	memset(&serveraddr, 0, sizeof(struct sockaddr_in));
	serveraddr.sin_family = AF_INET;   
	serveraddr.sin_port = htons(port);
	serveraddr.sin_addr.s_addr = inet_addr(ip); //returnerer -1 hvis feil

	if((sd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0){ //lage socket
		fprintf(stderr, "Error while connecting to socket\n");
		exit(1);
	}

	if(connect(sd, (struct sockaddr *)&serveraddr, sizeof(struct sockaddr_in)) < 0){ //tilkoble til serveren
		fprintf(stderr, "Error while connecting\n");
		exit(1);
	}

	printf("! You are connected to the server \n"
				"! Please press a key:\n"
				"! [1] list content of current directory (ls)\n"
				"! [2] print name of current directory (pwd)\n"
				"! [3] change current directory (cd)\n"
				"! [4] get file information\n"
				"! [5] display file (cat)\n"
				"! [?] this menu\n"
				"! [q] quit\n");

	while(1){
		char msg[CMD_LENGTH]; memset(msg, 0, CMD_LENGTH);
		//passer på input og sjekker om brukeren taster inn riktig menyvalg eller ikke. hvis ikke, gir beskjed
		while(((msg[0] < '1' || msg[0] > '5') && msg[0] != 'q') || (strlen(msg) != 2)){
			display_menu();
			fgets(msg, CMD_LENGTH, stdin);
			if((msg[0] < '1' || msg[0] > '5') && msg[0] != '?'){
				printf("Type one of these commands: 1 2 3 4 5 ? or q \n");
			}

			if(msg[0] == '?'){
				printf("! You are connected to the server \n"
				"! Please press a key:\n"
				"! [1] list content of current directory (ls)\n"
				"! [2] print name of current directory (pwd)\n"
				"! [3] change current directory (cd)\n"
				"! [4] get file information\n"
				"! [5] display file (cat)\n"
				"! [?] this menu\n"
				"! [q] quit\n");
			}
		}


		if(msg[0] == 'q'){
			close(sd); 
			printf("Closing..\n"); 
			exit(0);
		}
		inputAction(msg[0], sd); //behandler kommando
	}
}


void display_menu(){ //kommandolinje
	printf("cmd (? for help)> ");
}

void inputAction(char a, int sd){
	switch(a){         
		  case '1': {
			printf("Sending ls\n");//check
			int st;
			st = send(sd, "ls", CMD_LENGTH , 0); //sender kommando til serveren
			
			if(st < 0){ //hvis ikke mulig å sende
				fprintf(stderr, "Error while sending\n");
				avslutte();
			}
			
			//nå venter vi på pakke fra serveren
			char *msg = receive_Serial_Pack(sd);
			
			manage_ls(msg);//behandler data mottatt
			free(msg);
		  } break;

		  case '2': {
			int st;
			st = send(sd, "pwd", CMD_LENGTH , 0); //samme prinsippet som med "ls"
			
			if(st < 0){
				fprintf(stderr, "Error while sending\n");
				avslutte();
			}
			
			char *msg = receive_Serial_Pack(sd);
			printf("%s\n", msg); //skriver ut pakken mottatt
			free(msg);
		  } break;

		  case '3': {
			char newPath[DIR_LENGTH]; memset(newPath, 0, DIR_LENGTH);
			int conti = 0;

			do{
				conti = 0;
				printf("new dir (? for help) > ");  //hvis bruker taster "?" "q" eller "enter"
				fgets(newPath, DIR_LENGTH, stdin);
				if(newPath[0] == '?' && newPath[1] == '\n'){
					menu_for_CD();
					conti = 1;
				}else if(newPath[0] == 'q' && newPath[1] == '\n'){
					return;
				}else if(newPath[0] == '\n'){
					conti = 1;
				}
			}while(conti);


			int st;
			st = send(sd, "cd", CMD_LENGTH , 0);

			if(st < 0){ //hvis det skjedde feil under sending til serveren
				fprintf(stderr, "Error while sending\n");
				avslutte();
			}

			newPath[strlen(newPath)-1] = '\0'; //må ikke glemme å sette på 0-byte på slutten av path-navn
			st = send(sd, newPath, DIR_LENGTH , 0); //sender path-navn til serveren

			if(st < 0){ //hvis feil oppstått
				fprintf(stderr, "Error while sending\n");
				avslutte();	
			}

			char *msg = receive_Serial_Pack(sd); //venter på pakken fra serveren
			printf("%s\n", msg); //skriver ut pakken mottatt
			free(msg);
		  } break;

		  case '4': {
			int st;
			st = send(sd, "ls", CMD_LENGTH , 0); //må begynne med "ls" kommando først
			
			if(st < 0){ //hvis feil oppstått
				fprintf(stderr, "Error while sending\n");
				avslutte();	
			}

			char *buf = receive_Serial_Pack(sd); //venter på pakken fra serveren
			
			//================ nå har vi ls ==================

			int antall =  manage_nr_for_ls(buf); //skriver ut meny for "getFileInfo" med tall, samt tilordner variabelen antall filer i directory
			int velgTall = hent_filNavnNr_via_nr(antall, buf); //tilordner denne variabelen filnummer tastet
			if(velgTall == -1) return; //hvis filnummer ikke eksisterer

			char fileName[FILE_LENGTH]; memset(fileName,0,FILE_LENGTH);
			getFilename(buf, velgTall, fileName); //får filnavn ifølge tastet filnummer
			free(buf);

			st = send(sd, "getFileInfo", CMD_LENGTH , 0); //sender kommando til serveren

			if(st < 0){ //hvis feil oppstått
				fprintf(stderr, "Error while sending\n");
				avslutte();
			}
			
			//====== naa sender vi filnavn til serveren =======
			st = send(sd, fileName, FILE_LENGTH, 0);

			if(st < 0){
				fprintf(stderr, "Error while sending\n");
				avslutte();
			}

			char *msg = receive_Serial_Pack(sd); //venter på pakken fra serveren
			printf("%s\n", msg); //skriver ut pakken mottatt
			free(msg);
		  } break;

		  case '5': {
			  int st;
			  st = send(sd, "ls", CMD_LENGTH , 0); //må begynne med "ls" først

			  if(st < 0){ //hvis feil oppstått
				fprintf(stderr, "Error while sending\n");
				avslutte();
			  }

			  char *buf = receive_Serial_Pack(sd); //venter på pakken fra serveren
  
			  //================ naa har vi ls ==================
  
			  int antall =  manage_nr_for_ls(buf); //skriver ut meny med tall
			  int velgTall = hent_filNavnNr_for_CAT(antall, buf);
			  if(velgTall == -1) return; //hvis filnummer ikke eksisterer

			  char fileName[FILE_LENGTH]; memset(fileName,0,FILE_LENGTH);
			  getFilename(buf,velgTall,fileName); //får filnavn ifølge filnummer tastet
			  free(buf);

			  st = send(sd, "cat", CMD_LENGTH , 0); //sender kommando til serveren

			  if(st < 0){ 
				fprintf(stderr, "Error while sending\n");
				avslutte();
			  }

			  // ======== naa sender vi filnavn til serveren ========
			  st = send(sd, fileName, FILE_LENGTH, 0);

			  if(st < 0){
				fprintf(stderr, "Error while sending\n");
				avslutte();
			  }

			  char *msg = receive_Serial_Pack(sd); //venter på pakken fra serveren
			  printf("%s\n", msg); //skriver ut
			  free(msg);
		  } break;
	}
}
