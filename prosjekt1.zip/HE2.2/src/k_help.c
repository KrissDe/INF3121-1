#include "../header/k_help.h"


void m_gethost(char hostName[], char ip[]){ //denne metoden printer ut IP addressen til hvilken som helst host man oppgir i kommandolinje
	struct addrinfo geth, *pointToList, *p;
	int st; //status
	char ipstr[INET_ADDRSTRLEN]; //for Ipv4

	memset(&geth, 0, sizeof geth);
	geth.ai_family = AF_UNSPEC; // AF_INET eller AF_INET6 
	geth.ai_socktype = SOCK_STREAM;

	if ((st = getaddrinfo(hostName, NULL, &geth, &pointToList)) != 0) {
		fprintf(stderr, "Error while getaddrinfo: %s\n", gai_strerror(st));
		exit(1);
	}

	for(p = pointToList;p != NULL; p = p->ai_next){
		void *address; // få peker til selve addressen

		if(p->ai_family == AF_INET){ // for IPv4
			struct sockaddr_in *ipv4 = (struct sockaddr_in *)p->ai_addr;
			address = &(ipv4->sin_addr);
		}

		// konvertere IP til string og legge inn i "ip"
		inet_ntop(p->ai_family, address, ipstr, sizeof ipstr);
		strcpy(ip, ipstr);
	}
	freeaddrinfo(pointToList); // free lenkeliste
}

void manage_ls(char buf[]){
	int i = 0;
	while(buf[i] != '\0'){ //frem til slutten av buffer
		if(i==0){
			printf("! "); //utropstegn kommer på begynnelsen av hver linje, passer på første linje
			printf("%c", buf[i]);
		}else{
			printf("%c", buf[i]);
		}
		
		if(buf[i] =='\n' && buf[i+1] != '\0'){ //hvis ny linje og ikke slutten av buffer
			printf("! "); //passer på hver neste ny linje
		}
		i++;
	}
}

int manage_nr_for_ls(char buf[]){
	int i = 0;
	int counter = 1; //nummer for filnavn i utskrift

	while(buf[i] != '\0'){//frem til slutten av buffer
		if(i==0){
			printf("! [%d] ", counter++); //passer på første linje
			printf("%c", buf[i]);
		}else{
			printf("%c", buf[i]);
		}

		if(buf[i] =='\n' && buf[i+1] != '\0'){
			printf("! [%d] ", counter++); //passer på hver neste ny linje
		}
		i++;
	}
	return counter-1;
}

void getFilename(char *buf, int nr, char *fileName){
	if(buf[strlen(buf)-1] == '\n') buf[strlen(buf)-1] = '\0'; //passer på 0-byte på slutten av buffer
	int i = 0, j=0;
	int counter = 1;

	while(buf[i] != '\0'){ //frem til slutten av buffer
		if(counter < nr){ //hvis counter er mindre enn filnummer tastet
			
		}else{ //hvis det er vårt filnummer
			fileName[j++] = buf[i]; //fyller vår array med data
			if(buf[i] == '\n' && buf[i+1] != '\0'){ //hvis ny linje og ikke slutten av buffer
				fileName[j-1] = '\0'; //setter på 0-byte på slutten av linje
				return;
			}
		}

		if(buf[i] =='\n' && buf[i+1] != '\0'){ //hvis ny linje og ikke slutten av buffer
			counter++;
		}
		i++;
	}
}

void menu_for_CD(){ //meny som skrives ut for kommando "cd"
	printf("! ..  the parent directory\n");
	printf("! /  a new absolute directory\n");
	printf("!  a new directory relative to the current position\n");
	printf("! [?]  this menu\n");
	printf("! [q]  leave this menu\n");
}

int hent_filNavnNr_via_nr(int antall, char *buf){
	  char msg[CMD_LENGTH]; memset(msg, 0, CMD_LENGTH);

	  do{
		printf("file (? for help)> ");
		fgets(msg, CMD_LENGTH, stdin);

		if(msg[0] == 'q' && msg[1] == '\n'){ //for å avslutte operasjonen
			return -1;
		}else if(msg[0] == '?' && msg[1] == '\n'){ //for "?"
			printf("! Get file information for:\n");
			manage_nr_for_ls(buf);
			printf("! [q] leave this menu\n");
			continue;
		}

		int i = atoi(msg); //omgjør til numeric
		if(i>0 && i<=antall){ //hvis nummer ikke er større enn antall filer i directory og ikke mindre enn 0
			return i;
		}
	  } while(1);
}

int hent_filNavnNr_for_CAT(int antall, char *buf){
	  char msg[CMD_LENGTH]; memset(msg, 0, CMD_LENGTH);

	  do{
		printf("file (? for help)> ");
		fgets(msg, CMD_LENGTH, stdin);

		if(msg[0] == 'q' && msg[1] == '\n'){ //hvis vil avslutte operasjonen
			return -1;
		}else if(msg[0] == '?' && msg[1] == '\n'){ //for "?"
			printf("! Get file content for:\n");
			manage_nr_for_ls(buf);
			printf("! [q] leave this menu\n");
			continue;
		}
		int i = atoi(msg); //omgjør til numeric

		if(i>0 && i<=antall){ //hvis større enn null og ikke større enn antall filer i directory
			return i;
		}
	  }while(1);
}

// ---- nå kommer metode som håndterer mottakkelse av alle deler av data som blir sendt fra serveren, og legger de sammen for å skrive ut ----

char *receive_Serial_Pack(int sd){ 
	int SIZE_STRUCT = sizeof(struct msg_del); // størrelse av vår struct som skal splitte data i deler for pakken
	char buf[SIZE_STRUCT]; memset(buf,0,SIZE_STRUCT);
	// --- nå skal jeg motta antall char ---
	int nbytes = recv(sd, buf, SIZE_STRUCT, 0);

	if(nbytes == 0){
		printf("%d closed connection\n", sd);
		close(sd);
		exit(-1);
	}else if(nbytes < 0){
		perror("Eror while receiving\n");
		close(sd);
		exit(-1);
	}

	struct msg_del *henteAntall = (struct msg_del *)buf; 

	int antallChar = ntohl(henteAntall->antall_Char); //konverterer fra nett for big endian
	char *msg = (char *)malloc(antallChar); memset(msg,0,antallChar); //allokerer minne for det antallet av char
	int i = 0;
	int sumChar = 0;

	while(sumChar < antallChar){
		char pakke[SIZE_STRUCT]; memset(pakke,0,SIZE_STRUCT);
		nbytes = recv(sd, pakke, SIZE_STRUCT, 0); //mottar pakken fra serveren

		if(nbytes == 0){
			printf("%d closed connection\n", sd);
			close(sd);
			exit(-1);
		}else if(nbytes < 0){
		    perror("Error while receiving\n");
		    close(sd);
		    exit(-1);
		}

	    struct msg_del *motatt_pakke = (struct msg_del *)pakke;
	    sumChar += ntohl(motatt_pakke->antall_Char); //konverterer fra nett for big endian
	    int j = 0;

	    while(j<ntohl(motatt_pakke->antall_Char)){
		  msg[i++] = motatt_pakke->msg_Innhold[j++]; //legger data fra mottatt pakke inn i vår array
	    }

	    fprintf(stderr, "    Har mottatt %d bytes. Det er en del av mld med size %d bytes.\n", nbytes, j); //check

	    #ifdef DEBUG 
		  fprintf(stderr,"    Har sendt %d bytes. Det er en del av mld med size %d bytes.\n", nbytes, j);
	    #endif 
	}
	fprintf(stderr,"Mottatt totalt %d bytes.\n", sumChar);
	return msg;
}









